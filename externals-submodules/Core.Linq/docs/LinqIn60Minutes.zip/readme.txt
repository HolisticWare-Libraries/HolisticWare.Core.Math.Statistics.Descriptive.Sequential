There are three similar folders:

OneHourLinq - After
OneHourLinq - Before
OneHourLinq - During

The "Before" folder contains tests without any implementation, i.e. what I had before the event.
The "During" folder is exactly what I had at the end of the event.
The "After" folder contains the implementation of everything I've got unit tests for. A few of the unit
tests have been improved too :)

I don't guarantee it's all correct - but please let me know if you find bugs and I'll try to fix them.